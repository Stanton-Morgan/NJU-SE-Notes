var express = require('express');
var app = express();
var cors = require('cors')
app.use(cors());

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'web'
});

connection.connect();

app.get('/register', function (req, res) {
    var params = req.query;
    console.log(params.mail)
    var q1 = "SELECT count(*) as ans from mytable where mail=" + "\"" + params.mail + "\"";
    var q2 = "INSERT INTO mytable(mail,phone,name,password) values(" + "\"" + params.mail + "\",\"" + params.phone + "\",\"" + params.name + "\",\"" + params.password + "\")";
    connection.query(q1, function (error, results, fields) {
        if (error) throw error;
        if (results[0].ans > 0) {
            console.log("邮箱已存在账号！")
            res.send("邮箱已存在账号！");
        } else {
            connection.query(q2);
            res.send("注册成功！");
        }
    });
}).listen(8080);

app.get('/login', function (req, res) {
    var params = req.query;
    console.log(params.mail)
    var q1 = "SELECT count(*) as ans from mytable where mail=" + "\"" + params.mail + "\"";
    var q2 = "SELECT password, phone, name from mytable where mail=" + "\"" + params.mail + "\"";
    connection.query(q1, function (error, results, fields) {
        if (error) throw error;
        if (results[0].ans === 0) {
            console.log("不存在该账号！")
            res.send("不存在该账号！");
        } else {
            connection.query(q2, function (error, results, fields) {
                if (error) throw error;
                // console.log(results)
                if (results[0].password !== params.password) {
                    console.log("密码错误！！")
                    res.send("密码错误！");
                } else {
                    console.log("成功登陆！")
                    res.send({"phone": results[0].phone, "name": results[0].name});
                }
            });
        }
    });
}).listen(8081);