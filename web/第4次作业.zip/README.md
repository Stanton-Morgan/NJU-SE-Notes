# Web前端-登录注册

## 1.前端实现

本次作业一共使用了4个页面：register.html(注册页面)，index.html（登陆页面），first.html（进入之后的一级页面），1.html（进入之后的二级页面）。

### 1.1 first.html

页面可显示登录用户信息

![](assets/2022-12-31-00-07-14-image.png)

未登录时页面如下，表示没有用户信息

![](assets/2022-12-31-00-08-02-image.png)

### 1.2 1.html

与first.html类似

![](assets/2022-12-31-00-09-17-image.png)

![](assets/2022-12-31-00-14-00-image.png)

### 1.3 register.html

![](assets/2022-12-31-00-15-40-image.png)

这个页面负责注册业务。代码过长，这里就不直接粘贴了，这里只体现几个要点。 

#### 1.2.1 CDN使用

使用了jQuery和axios的CDN，这样就避免了在前端使用npm。（但是火狐浏览器似乎不支持CDN，请使用Chrome体验。）

#### 1.2.2 密码强度提示

```js
$('#password').keyup(function () {
        let password = document.getElementsByClassName('input')[3];
        let l = password.value.length;
        let p = document.getElementsByClassName('passwordHint')[0];
        if (l <= 6) {
            p.innerText = '不安全';
            p.style.color = 'red';
        } else if (l <= 12) {
            p.innerText = '中等';
            p.style.color = 'yellow';
        } else {
            p.innerText = '安全';
            p.style.color = 'green';
        }
    })
```

![](assets/2022-12-31-00-17-16-image.png)

#### 1.2.3 密码加密方式

密码加密使用了JavaScript中自带的bToa方法，并且加入了固定的盐。

```js
let password = document.getElementsByClassName('input')[3];
let l = password.value.length;
```

#### 1.2.4 axios传递到后端

```js
let request = "http://localhost:8080/register?mail=" + inputs[0].value + "&phone=" + inputs[1].value + "&name=" + inputs[2].value + "&password=" + pass;
            axios.get(request).then(function (data) {
                if (data.data === '邮箱已存在账号！') {
                    alert("邮箱已存在账号！");
                } else {
                    alert("注册成功")
                    // window.location.href = 'index.html';
                    window.location.replace('index.html');
                    return false;
                }
            })
```

#### 1.2.5 验证码功能

验证码通过随机生成+画布绘制来生成。每次点击都会重置验证码

```js
var code;
    window.onload = function () {
        createCode();
    }

    function createCode() {
        code = "";
        var codeLength = 4;
        var random = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
            'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        for (var i = 0; i < codeLength; i++) { //循环操作
            var charIndex = Math.floor(Math.random() * 36);
            code += random[charIndex];
        }
        console.log(code);
        let canvas = document.createElement("canvas");
        canvas.width = 100;
        canvas.height = 50;
        let ctx = canvas.getContext("2d");
        ctx.fillStyle = "#000";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.fillStyle = "#FFF";
        ctx.font = "24px 黑体";
        ctx.fillText(code, 25, 35);
        let img = new Image();
        img.src = canvas.toDataURL("image/png");
        img.id = 'checkImg';
        img.style.opacity = 0.3;
        img.style.position = 'absolute';

        let check = document.getElementById("check");
        check.appendChild(img);

        // document.body.appendChild(img);
        $('#check').click(function () {
            let img = document.getElementById('checkImg');
            img.parentElement.removeChild(img);
            createCode();
        })
    }
```

#### 1.2.6 注册提示

如果没有输入用户名、密码，或者用户邮箱已经存在，则会出现提示

![](assets/2022-12-31-00-21-16-image.png)

![](assets/2022-12-31-00-20-48-image.png)

### 1.3 index.html

![](assets/2022-12-31-00-33-43-image.png)

登陆成功会显示如下弹窗，并跳转first.html页面

![](assets/2022-12-31-00-13-39-image.png)

这个页面主要负责登陆功能，除了上面提出的CDN、密码加密方式、axios、提示等重要手段，这里还有一些其他的要点。

## 2.后端实现

后端只写了一个login.js这一个文件。

在编写后端之前，需要确保nodejs、mysql等安装成功。然后在项目目录下的终端中导入如下三个包：

```shell
npm install express
npm install cors
npm install mysql
```

然后按照前端传来的请求编写后端即可：

```js
var express = require('express');
var app = express();
var cors = require('cors')
app.use(cors());

var mysql = require('mysql');
var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'web'
});

connection.connect();

app.get('/register', function (req, res) {
    var params = req.query;
    console.log(params.mail)
    var q1 = "SELECT count(*) as ans from mytable where mail=" + "\"" + params.mail + "\"";
    var q2 = "INSERT INTO mytable(mail,phone,name,password) values(" + "\"" + params.mail + "\",\"" + params.phone + "\",\"" + params.name + "\",\"" + params.password + "\")";
    connection.query(q1, function (error, results, fields) {
        if (error) throw error;
        if (results[0].ans > 0) {
            console.log("邮箱已存在账号！")
            res.send("邮箱已存在账号！");
        } else {
            connection.query(q2);
            res.send("注册成功！");
        }
    });
}).listen(8080);

app.get('/login', function (req, res) {
    var params = req.query;
    console.log(params.mail)
    var q1 = "SELECT count(*) as ans from mytable where mail=" + "\"" + params.mail + "\"";
    var q2 = "SELECT password, phone, name from mytable where mail=" + "\"" + params.mail + "\"";
    connection.query(q1, function (error, results, fields) {
        if (error) throw error;
        if (results[0].ans === 0) {
            console.log("不存在该账号！")
            res.send("不存在该账号！");
        } else {
            connection.query(q2, function (error, results, fields) {
                if (error) throw error;
                // console.log(results)
                if (results[0].password !== params.password) {
                    console.log("密码错误！！")
                    res.send("密码错误！");
                } else {
                    console.log("成功登陆！")
                    res.send({"phone": results[0].phone, "name": results[0].name});
                }
            });
        }
    });
}).listen(8081);
```

每次启动时，只要在命令行中键入如下命令即可启动后端：

```shell
node login.js
```

## 3.数据库

数据库文件即为a.sql。


