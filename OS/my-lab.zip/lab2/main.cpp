#include <fstream>
#include <iostream>
#include <string>
#include <regex>
#include <vector>

using namespace std;

void read();
int searchTargetDir(int target, string des);
int searchTargetFile(int target, string name);
void search(int target, string addr, bool l);
int *countNums(int target);
bool isTrue(char t);
// bool check(string s);
void printSentence(string s, bool b);
void stringSplit(const string &str, const string &splits, vector<string> &res);
void handleDirs(vector<string> &dirs);
extern "C"
{
	void printWhite(char *, int);
	void printRed(char *, int);
}

int file[2000000];
string path = "/mnt/hgfs/VM-Share/OS/a2.img";

int main()
{
	read();
	while (true)
	{
		printSentence("请输入指令(ls,cat,exit):\n", true);
		string s;
		getline(cin, s);

		string cmd[100], t = "";
		int options = 0;
		for (int i = 0; i <= s.length(); i++)
		{
			if (s[i] == ' ' || i == s.length())
			{
				if (t == "")
					continue;
				cmd[options++] = t;
				t = "";
			}
			else
			{
				t = t + s[i];
			}
		}

		if (cmd[0] != "ls" && cmd[0] != "cat" && cmd[0] != "exit")
		{
			printSentence("指令格式错误,请重新输入！\n", true);
			continue;
		}

		// exit
		if (cmd[0] == "exit")
		{
			if (options == 1) // cmd:exit
			{
				break;
			}
			else
			{
				printSentence("输入格式错误,exit后不能有附加指令\n", true);
			}
			continue;
		}

		// cat
		if (cmd[0] == "cat")
		{
			if (options != 2)
			{
				printSentence("输入格式错误,cat不能接受两个及以上的参数!\n", true);
			}
			else
			{
				vector<string> dirs;
				string address = "";
				int target = 19 * 512; // 19*512
				stringSplit(cmd[1], "/", dirs);
				handleDirs(dirs);
				while (dirs.size() > 1)
				{
					string des = dirs[0];
					dirs.erase(dirs.begin());
					// int i = 1;
					// while (address[i] != '/')
					// { // des
					// 	des = des + address[i++];
					// }
					// address = address.substr(i);

					target = searchTargetDir(target, des);
					if (target == -1)
					{
						break;
					}
				}
				if (target == -1)
				{
					printSentence("目标目录不存在!\n", true);
					continue;
				}
				target = searchTargetFile(target, dirs[0]);
				if (target == -1)
				{
					printSentence("目标文件不存在!\n", true);
					continue;
				}
				int cluster = target / 512 - 33 + 2; //计算簇数，从33号扇区开始，起始对应编号为2
				while (true)
				{
					int i = 0;
					string str = "";
					for (i = 0; file[target + i] != 0 && i < 512; i++)
					{
						char c = (char)file[target + i];
						str = str + c;
					}
					printSentence(str, true);
					if (i != 512)
					{ //文件结束
						break;
					}
					if (cluster % 2 == 0)
					{ // FAT12: 12位代表一个FAT项，2个FAT占3个字节
						int fat12 = 512 + cluster / 2 * 3;
						cluster = ((file[fat12 + 1] & 0x0F) << 8) | file[fat12]; //左移8位（低位补零），计算簇数
					}
					else
					{
						int fat12 = 513 + cluster / 2 * 3;
						cluster = (file[fat12 + 1] << 4) | (file[fat12] >> 4 & 0x0F);
					}
					target = 512 * 33 + (cluster - 2) * 512; //重新计算tgt
				}
				printSentence("\n", true);
			}
			continue;
		}

		// ls
		if (cmd[0] == "ls")
		{
			bool state = false;
			string address = "";
			vector<string> dirs; //各级目录
			bool flag = true;
			int dirCnt = 0;
			for (int i = 1; i < options; i++)
			{
				if (cmd[i][0] == '-')
				{
					flag = flag & regex_match(cmd[i], regex("-l+")); //形如l ll lll的
					if (!flag)
					{
						break;
					}
					state = true;
				}
				else if (dirCnt == 0)
				{ //目录
					dirCnt = 1;
					if (cmd[i][cmd[i].length() - 1] == '/')
					{
						cmd[i] = cmd[i].substr(0, cmd[i].length() - 1);
					}
					stringSplit(cmd[i], "/", dirs);
					handleDirs(dirs);
					for (int idx = 0; idx < dirs.size(); idx++)
					{
						address += dirs[idx] + '/';
					}
					address = address.substr(0, address.length() - 1);
					// printSentence(address + '\n', true);
				}
				else
				{
					flag = false;
					continue;
				}
			}
			if (!flag)
			{
				printSentence("输入格式错误\n", true);
				continue;
			}

			int target = 19 * 512; //根目录文件项起始
			string des = "";
			while (!dirs.empty())
			{ //去除路径分隔符
				des = dirs[0];
				dirs.erase(dirs.begin());
				target = searchTargetDir(target, des);
				// printSentence(des +'\n', true);
				if (target == -1)
				{
					break;
				}
			}
			if (target == -1)
			{
				printSentence("输入格式错误,目标目录不存在\n", true);
				continue;
			}
			search(target, address, state);
		}
	}
}

// b.img为1440KB,即1440*1024=1474560B
void read()
{
	ifstream infile(path, ios::binary);
	char buf[1];
	int p = 0;
	while (!infile.eof())
	{
		infile.read(buf, 1);
		int t = buf[0];
		if (t < 0)
		{
			t = 256 + t;
		}
		file[p] = t;
		p++;
	}
	infile.close();
}

// 19-32号扇区为根目录文件项
//从根目录文件项起始位开始向后寻找目录
int searchTargetDir(int target, string des)
{
	while (true)
	{
		if (file[target] == 0)
		{
			break;
		}
		int flag = 0;
		for (int i = 0; i < 11; i++) // 0-10B是名字，文件的话，8-10B是后缀
		{
			if (!isTrue(file[target + i]))
			{
				target += 32; //每个目录项为32B，跳到下一项
				flag = -1;
				break;
			}
		}
		if (flag == -1)
		{
			continue;
		}
		if (file[target + 11] == 0x10) // 11B为属性xiang：15——长目录项，可跳过；16：文件夹；32：文件
		{
			string m = "";
			for (int i = 0; i < 11; i++)
			{
				if (file[target + i] != 0x20)
				{ //不是文件则为路径
					m = m + char(file[target + i]);
				}
			}
			if (m == des)
			{													 // 33号扇区往后为数据区，26-27B表示在数据区的簇号
				return 512 * 33 + (file[target + 26] - 2) * 512; // 数据区起始地址对应编号为2
			}
		}
		target += 32;
	}
	return -1;
}

int searchTargetFile(int target, string name)
{
	while (true)
	{
		if (file[target] == 0)
		{
			break;
		}
		int flag = 0;
		for (int i = 0; i < 11; i++)
		{
			if (!isTrue(file[target + i]))
			{
				target += 32;
				flag = -1;
				break;
			}
		}
		if (flag == -1)
		{
			continue;
		}
		if (file[target + 11] == 0x20) // 11B属性，0x20代表文件
		{
			string m = "";
			for (int i = 0; i < 8; i++) // 0-7B名字
			{
				if (file[target + i] != 0x20)
					m = m + char(file[target + i]);
			}
			if (file[target + 8] != 0x20)
			{
				m = m + ".";
			}
			for (int i = 8; i < 11; i++) // 8-10B：.后缀
			{
				if (file[target + i] != 0x20)
					m = m + char(file[target + i]);
			}
			if (m == name)
			{
				return 512 * 33 + (file[target + 26] - 2) * 512;
			}
		}
		target += 32;
	}
	return -1;
}

// ls，根据tgt,addr,l输出结果
void search(int target, string addr, bool l)
{
	string dir[100];
	string files[100];
	int targets[100], size[100], point1 = 0, point2 = 0; //最多100个

	while (true)
	{
		if (file[target] == 0)
		{
			break;
		}
		int flag = 0;
		for (int i = 0; i < 11; i++)
		{
			if (!isTrue(file[target + i]))
			{
				target += 32;
				flag = -1;
				break;
			}
		}
		if (flag == -1)
		{
			continue;
		}
		if (file[target + 11] == 0x10)
		{
			string m = "";
			for (int i = 0; i < 11; i++)
			{
				if (file[target + i] != 0x20)
					m = m + char(file[target + i]);
			}
			dir[point1] = m;
			targets[point1++] = 512 * 33 + (file[target + 26] - 2) * 512;
		}
		else if (file[target + 11] == 0x20)
		{
			string m = "";
			for (int i = 0; i < 8; i++)
			{
				if (file[target + i] != 0x20)
					m = m + char(file[target + i]);
			}
			if (file[target + 8] != 0x20)
			{
				m = m + ".";
			}
			for (int i = 8; i < 11; i++)
			{
				if (file[target + i] != 0x20)
					m = m + char(file[target + i]);
			}
			files[point2] = m;
			size[point2++] = file[target + 28] + file[target + 29] * 256;
		}
		target += 32;
	}

	if (l)
	{
		printSentence(addr + "/  " + to_string(point1) + "  " + to_string(point2) + ":\n", true);

		if (addr != "")
		{
			printSentence(".\n..\n", false);
		}

		for (int i = 0; i < point2; i++)
		{
			printSentence(files[i] + "  " + to_string(size[i]) + "\n", true);
		}

		for (int i = 0; i < point1; i++)
		{
			int *p = countNums(targets[i]);
			printSentence(dir[i], false);
			printSentence("  " + to_string(p[0]) + "  " + to_string(p[1]) + "\n", true);
		}
	}
	else
	{
		printSentence(addr + "/:\n", true);

		string o = "";

		if (addr != "")
		{
			o = o + ".  ..  ";
		}

		for (int i = 0; i < point1; i++)
		{
			o = o + dir[i] + "  ";
		}
		printSentence(o, false);
		o = "";

		for (int i = 0; i < point2; i++)
		{
			o = o + files[i] + "  ";
		}
		printSentence(o, true);
	}
	printSentence("\n", true);

	for (int i = 0; i < point1; i++)
	{
		if (dir[i] != "." && dir[i] != "..")
		{
			search(targets[i], addr + "/" + dir[i], l);
		}
	}
}

int *countNums(int target)
{
	int *p = new int[2];
	p[0] = 0;
	p[1] = 0;
	while (true)
	{
		if (file[target] == 0)
		{
			break;
		}
		int g = 0;
		for (int i = 0; i < 11; i++)
		{
			if (!isTrue(file[target + i]))
			{
				target += 32;
				g = -1;
				break;
			}
		}
		if (g == -1)
		{
			continue;
		}
		if (file[target + 11] == 0x10)
		{
			p[0]++;
		}
		else if (file[target + 11] == 0x20)
		{
			p[1]++;
		}
		target += 32;
	}
	return p;
}

bool isTrue(char t)
{ //判断名字是否只含字母数字
	if (t == ' ')
	{
		return true;
	}
	if (t >= 'a' && t <= 'z')
	{
		return true;
	}
	if (t >= 'A' && t <= 'Z')
	{
		return true;
	}
	if (t >= '0' && t <= '9')
	{
		return true;
	}
	return false;
}

// bool check(string s)
// {
// 	if (s[0] != '/')
// 	{
// 		return true;
// 	}
// 	int flag = true;
// 	for (int i = 1; i < s.length(); i++)
// 	{
// 		if (s[i] == '/')
// 		{
// 			return false;
// 		}
// 	}
// 	return true;
// }

void printSentence(string s, bool b)
{ // true:白色 false:红色
	if (b)
	{
		printWhite((char *)s.c_str(), s.length());
	}
	else
	{
		printRed((char *)s.c_str(), s.length());
	}
}
// 使用字符串分割
void stringSplit(const string &str, const string &splits, vector<string> &res)
{
	if (str == "")
		return;
	//在字符串末尾也加入分隔符，方便截取最后一段
	string strs = str + splits;
	size_t pos = strs.find(splits);
	int step = splits.size();

	// 若找不到内容则字符串搜索函数返回 npos
	while (pos != strs.npos)
	{
		string temp = strs.substr(0, pos);
		res.push_back(temp);
		//去掉已分割的字符串,在剩下的字符串中进行分割
		strs = strs.substr(pos + step, strs.size());
		pos = strs.find(splits);
	}
}

void handleDirs(vector<string> &dirs)
{
	for (int i = 0; i < dirs.size();)
	{
		if (dirs[i] == "." || dirs[i] == "") //忽略，无影响
		{
			dirs.erase(dirs.begin() + i);
			continue;
		}
		else if (dirs[i] == "..")
		{
			if (i == 0) //../NJU
			{
				dirs.erase(dirs.begin());
				continue;
			}
			else // NJU/../NJU
			{
				dirs.erase(dirs.begin() + i - 1, dirs.begin() + i + 1); //删除i-1，i
				i -= 1;
			}
		}
		else
			i += 1;
	}
}
